import numpy as np

li = [2,3,4,5,6]

ar = np.array(li)
print(ar)

print(type(ar))
