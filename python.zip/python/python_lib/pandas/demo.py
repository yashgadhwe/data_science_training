import pandas as pd

df = pd.read_csv("https://raw.githubusercontent.com/singhrau0/Big-Data-Preprocessing/main/titanic_dataset.csv")

print(df)
