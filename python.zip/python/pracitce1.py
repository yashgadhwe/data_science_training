a = 22
print(a)
